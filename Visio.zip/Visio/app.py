"""
Application Flask — Plateforme de traitement des déchets.

Flux citoyen (après scan du QR) :
  1. La page /signaler/<id> affiche le lieu de la poubelle.
  2. Le citoyen prend une photo ET choisit le niveau (vide / à moitié / pleine).
  3. À l'envoi :
       - la photo est stockée,
       - l'IA extrait les caractéristiques (Point 3) et décide d'un verdict (Point 4),
       - on compare l'avis du citoyen et celui de l'IA (l'IA fait foi),
       - on enregistre le tout et on attribue un statut à la poubelle.
  4. Une page de confirmation montre le verdict.

Lancer :
    python app.py
Puis http://localhost:5000/
"""

import os
import json
from datetime import datetime
from werkzeug.utils import secure_filename
from functools import wraps
from flask import (
    Flask, request, redirect, url_for,
    render_template_string, abort, send_from_directory, session,
)

from database import (
    init_db, get_poubelle, lister_poubelles, ajouter_signalement,
    LABELS_VALIDES, LABEL_AFFICHAGE,
    verifier_limite, enregistrer_tentative, nettoyer_vieilles_tentatives,
    LIMITE_UPLOADS, FENETRE_MINUTES,
    statut_actuel_poubelle, donnees_carte, repartition_statuts,
    signalements_par_jour, poubelles_pleines, zones_a_risque, compter_signalements,
    get_seuils, maj_seuils, reinitialiser_seuils, SEUILS_PAR_DEFAUT,
    lister_regles, ajouter_regle, supprimer_regle, basculer_regle,
    CARACTERISTIQUES_REGLES, OPERATEURS_REGLES,
)
from vision import analyser_image, comparer_citoyen_ia

# --- Configuration ---
DOSSIER_UPLOADS = "uploads"
EXTENSIONS_AUTORISEES = {"jpg", "jpeg", "png"}
TAILLE_MAX = 10 * 1024 * 1024  # 10 Mo

# Mot de passe d'accès au dashboard agents (à changer en production !)
MOT_DE_PASSE_AGENTS = "agent2024"
# ---------------------

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = TAILLE_MAX
# Clé secrète nécessaire pour gérer les sessions (connexion agents).
# En production, mettre une vraie valeur aléatoire secrète.
app.secret_key = "change-moi-en-production-cle-secrete-aleatoire"

os.makedirs(DOSSIER_UPLOADS, exist_ok=True)
init_db()


def extension_autorisee(nom_fichier):
    return "." in nom_fichier and \
        nom_fichier.rsplit(".", 1)[1].lower() in EXTENSIONS_AUTORISEES


def ip_du_client():
    """
    Récupère l'IP réelle du citoyen.
    Derrière ngrok / un proxy, l'IP d'origine est dans l'en-tête X-Forwarded-For
    (le premier élément de la liste). Sinon on prend l'IP directe.
    """
    xff = request.headers.get("X-Forwarded-For", "")
    if xff:
        return xff.split(",")[0].strip()
    return request.remote_addr or "inconnue"


def format_attente(secondes):
    """Transforme un nombre de secondes en texte lisible (ex: '12 min 30 s')."""
    minutes = secondes // 60
    sec = secondes % 60
    if minutes and sec:
        return f"{minutes} min {sec} s"
    if minutes:
        return f"{minutes} min"
    return f"{sec} s"


# ====================== PAGE D'ACCUEIL ======================
PAGE_ACCUEIL = """
<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><title>SmartWaste</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body{font-family:system-ui,sans-serif;max-width:600px;margin:2rem auto;padding:0 1rem;color:#1a1a1a}
  h1{font-size:1.4rem}
  a.lien{display:block;padding:.8rem 1rem;margin:.4rem 0;background:#f0f4f0;border-radius:8px;
    text-decoration:none;color:#1a5c1a;border:1px solid #d0e0d0}
  a.lien:hover{background:#e0ece0}
  .dash{background:#1a5c1a;color:#fff;text-align:center;font-weight:600}
  small{color:#666}
</style></head>
<body>
  <h1>SmartWaste</h1>
  <a class="lien dash" href="{{ url_for('dashboard') }}">📊 Tableau de bord agents</a>
  <p><small>Poubelles enregistrées (cliquer = simuler un scan de QR) :</small></p>
  {% for p in poubelles %}
    <a class="lien" href="{{ url_for('signaler', id_poubelle=p['id']) }}">
      {{ p['id'] }} — {{ p['nom_lieu'] }}
    </a>
  {% endfor %}
</body></html>
"""


# ====================== PAGE DE SIGNALEMENT (citoyen) ======================
PAGE_SIGNALER = """
<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><title>Signaler — {{ poubelle['id'] }}</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body{font-family:system-ui,sans-serif;max-width:500px;margin:0 auto;padding:1.5rem;color:#1a1a1a}
  .carte{background:#f0f4f0;border:1px solid #d0e0d0;border-radius:12px;padding:1.2rem;margin-bottom:1.5rem}
  .id{font-size:1.1rem;font-weight:700;color:#1a5c1a}
  .lieu{font-size:1rem;margin-top:.3rem}
  h2{font-size:1.05rem;margin:1.2rem 0 .6rem}
  label.btn{display:block;width:100%;box-sizing:border-box;text-align:center;
    padding:1rem;border-radius:10px;font-size:1.05rem;font-weight:600;cursor:pointer;
    background:#1a5c1a;color:#fff;margin-bottom:1rem}
  input[type=file]{display:none}
  #apercu{width:100%;border-radius:10px;margin-bottom:1rem;display:none}
  .niveaux{display:flex;gap:.5rem;margin-bottom:1rem}
  .niveaux input{display:none}
  .niveaux label{flex:1;text-align:center;padding:.9rem .3rem;border-radius:10px;cursor:pointer;
    font-weight:700;color:#fff;opacity:.55;transition:opacity .15s}
  .niveaux input:checked + label{opacity:1;outline:3px solid #0008}
  .lv{background:#2e8b57}.lm{background:#e0a800}.lp{background:#c0392b}
  input[type=submit]{width:100%;padding:1rem;border:none;border-radius:10px;
    background:#0a7;color:#fff;font-size:1.05rem;font-weight:700;cursor:pointer}
  input[type=submit]:disabled{background:#aaa;cursor:not-allowed}
  .nomf{text-align:center;color:#444;margin-bottom:1rem;min-height:1.2rem}
</style></head>
<body>
  <div class="carte">
    <div class="id">{{ poubelle['id'] }}</div>
    <div class="lieu">📍 {{ poubelle['nom_lieu'] }}</div>
  </div>

  <form method="post" enctype="multipart/form-data">
    <h2>1. Photo de la poubelle</h2>
    <label class="btn" for="photo">📷 Prendre / choisir une photo</label>
    <input id="photo" type="file" name="photo" accept="image/*" capture="environment" required>
    <img id="apercu" alt="aperçu">
    <div class="nomf" id="nomf"></div>

    <h2>2. Selon vous, la poubelle est :</h2>
    <div class="niveaux">
      <input type="radio" id="n_vide" name="eval_citoyen" value="vide" required>
      <label class="lv" for="n_vide">Vide</label>
      <input type="radio" id="n_moitie" name="eval_citoyen" value="a_moitie">
      <label class="lm" for="n_moitie">À moitié</label>
      <input type="radio" id="n_pleine" name="eval_citoyen" value="pleine">
      <label class="lp" for="n_pleine">Pleine</label>
    </div>

    <input type="submit" value="Envoyer le signalement">
  </form>

  <script>
    const input = document.getElementById('photo');
    input.addEventListener('change', () => {
      if (input.files && input.files[0]) {
        const apercu = document.getElementById('apercu');
        apercu.src = URL.createObjectURL(input.files[0]);
        apercu.style.display = 'block';
        document.getElementById('nomf').textContent = input.files[0].name;
      }
    });
  </script>
</body></html>
"""


# ====================== PAGE DE CONFIRMATION ======================
PAGE_MERCI = """
<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><title>Merci</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body{font-family:system-ui,sans-serif;max-width:500px;margin:0 auto;padding:2rem;text-align:center;color:#1a1a1a}
  .ok{font-size:3rem}
  h1{color:#1a5c1a;font-size:1.3rem}
  .res{background:#f0f4f0;border:1px solid #d0e0d0;border-radius:12px;padding:1.2rem;margin:1.2rem 0;text-align:left}
  .res div{margin:.4rem 0}
  .badge{display:inline-block;padding:.2rem .6rem;border-radius:6px;color:#fff;font-weight:700}
  .b_vide{background:#2e8b57}.b_a_moitie{background:#e0a800}.b_pleine{background:#c0392b}
  .accord{color:#2e8b57;font-weight:600}.desaccord{color:#c0392b;font-weight:600}
  .alerte{background:#c0392b;color:#fff;padding:.8rem;border-radius:10px;font-weight:700;margin-top:1rem}
  a{color:#1a5c1a}
</style></head>
<body>
  <div class="ok">✅</div>
  <h1>Signalement enregistré</h1>
  <div class="res">
    <div>Votre évaluation : <span class="badge b_{{ eval_citoyen }}">{{ aff[eval_citoyen] }}</span></div>
    <div>Analyse de l'IA : <span class="badge b_{{ verdict_ia }}">{{ aff[verdict_ia] }}</span></div>
    <div>
      {% if accord %}<span class="accord">✓ L'IA confirme votre évaluation</span>
      {% else %}<span class="desaccord">✗ L'IA a corrigé l'évaluation</span>{% endif %}
    </div>
  </div>
  {% if verdict_ia == 'pleine' %}
    <div class="alerte">🚨 Poubelle pleine — alerte envoyée aux services de collecte</div>
  {% endif %}
  <p style="margin-top:1.5rem"><a href="{{ url_for('accueil') }}">← Retour</a></p>
</body></html>
"""


# ====================== PAGE DE REJET (photo non conforme) ======================
PAGE_REJET = """
<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><title>Photo non conforme</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body{font-family:system-ui,sans-serif;max-width:500px;margin:0 auto;padding:2rem;text-align:center;color:#1a1a1a}
  .ko{font-size:3rem}
  h1{color:#c0392b;font-size:1.3rem}
  .raison{background:#fdecea;border:1px solid #f5c6cb;border-radius:12px;padding:1.2rem;margin:1.2rem 0;color:#a3221a;font-weight:600}
  a.btn{display:inline-block;margin-top:1rem;padding:.9rem 1.4rem;background:#1a5c1a;color:#fff;
    text-decoration:none;border-radius:10px;font-weight:600}
</style></head>
<body>
  <div class="ko">📷❌</div>
  <h1>Photo non conforme</h1>
  <div class="raison">{{ raison }}</div>
  <p>Votre signalement n'a pas été enregistré. Merci de reprendre une photo.</p>
  <a class="btn" href="{{ url_for('signaler', id_poubelle=poubelle['id']) }}">↻ Reprendre une photo</a>
</body></html>
"""


# ====================== PAGE LIMITE DÉPASSÉE (anti-spam) ======================
PAGE_LIMITE = """
<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><title>Trop de signalements</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body{font-family:system-ui,sans-serif;max-width:500px;margin:0 auto;padding:2rem;text-align:center;color:#1a1a1a}
  .ic{font-size:3rem}
  h1{color:#e0a800;font-size:1.3rem}
  .box{background:#fff8e1;border:1px solid #ffe08a;border-radius:12px;padding:1.2rem;margin:1.2rem 0;color:#7a5b00}
  .attente{font-size:1.4rem;font-weight:700;color:#c0392b;margin:.4rem 0}
  a{color:#1a5c1a}
</style></head>
<body>
  <div class="ic">⏳</div>
  <h1>Trop de signalements</h1>
  <div class="box">
    Vous avez atteint la limite de {{ limite }} signalements en {{ fenetre }} minutes
    pour cette poubelle ({{ poubelle['id'] }}).<br>
    Merci de réessayer dans :
    <div class="attente">{{ attente }}</div>
  </div>
  <p>Cette limite protège le service contre les envois abusifs.</p>
  <p style="margin-top:1.5rem"><a href="{{ url_for('accueil') }}">← Retour</a></p>
</body></html>
"""


@app.route("/")
def accueil():
    return render_template_string(PAGE_ACCUEIL, poubelles=lister_poubelles())


@app.route("/signaler/<id_poubelle>", methods=["GET", "POST"])
def signaler(id_poubelle):
    poubelle = get_poubelle(id_poubelle)
    if poubelle is None:
        abort(404, description="Poubelle inconnue. Le QR code n'est pas valide.")

    if request.method == "POST":
        # 0) Limitation de débit (anti-spam) : max N uploads / fenêtre par (IP + poubelle)
        ip = ip_du_client()
        autorise, secondes = verifier_limite(ip, id_poubelle)
        if not autorise:
            return render_template_string(
                PAGE_LIMITE, poubelle=poubelle,
                attente=format_attente(secondes),
                limite=LIMITE_UPLOADS, fenetre=FENETRE_MINUTES,
            ), 429  # 429 = Too Many Requests

        # On enregistre la tentative (même si la photo sera ensuite rejetée :
        # ça empêche de spammer le serveur avec des photos non conformes).
        enregistrer_tentative(ip, id_poubelle)
        nettoyer_vieilles_tentatives()

        # 1) Vérifs photo
        if "photo" not in request.files:
            abort(400, description="Aucune photo reçue.")
        fichier = request.files["photo"]
        if fichier.filename == "":
            abort(400, description="Aucun fichier sélectionné.")
        if not extension_autorisee(fichier.filename):
            abort(400, description="Format non autorisé (JPG ou PNG).")

        # 2) Évaluation citoyenne
        eval_citoyen = request.form.get("eval_citoyen")
        if eval_citoyen not in LABELS_VALIDES:
            abort(400, description="Évaluation citoyenne manquante ou invalide.")

        # 3) Sauvegarde de la photo
        ext = fichier.filename.rsplit(".", 1)[1].lower()
        horodatage = datetime.now().strftime("%Y%m%d_%H%M%S")
        nom_sauvegarde = secure_filename(f"{id_poubelle}_{horodatage}.{ext}")
        chemin = os.path.join(DOSSIER_UPLOADS, nom_sauvegarde)
        fichier.save(chemin)

        # 4) Analyse IA : conformité (qualité) PUIS niveau (Points 3 + 4)
        res = analyser_image(chemin)

        # 4bis) Si la photo n'est pas conforme : on rejette, on supprime la photo,
        # et on ne crée PAS de signalement (donnée inexploitable).
        if not res["conforme"]:
            try:
                os.remove(chemin)
            except OSError:
                pass
            return render_template_string(
                PAGE_REJET, poubelle=poubelle, raison=res["raison_rejet"],
            )

        verdict_ia = res["verdict"]
        features = res["features"]

        # 5) Comparaison citoyen / IA (l'IA fait foi)
        statut, accord = comparer_citoyen_ia(eval_citoyen, verdict_ia)

        # 6) Enregistrement complet
        ajouter_signalement(
            poubelle_id=id_poubelle,
            chemin_image=chemin,
            eval_citoyen=eval_citoyen,
            verdict_ia=verdict_ia,
            statut=statut,
            accord=accord,
            features_json=json.dumps(features, ensure_ascii=False),
        )

        return render_template_string(
            PAGE_MERCI, eval_citoyen=eval_citoyen, verdict_ia=verdict_ia,
            accord=accord, aff=LABEL_AFFICHAGE,
        )

    return render_template_string(PAGE_SIGNALER, poubelle=poubelle)


@app.route("/uploads/<nom>")
def fichier_upload(nom):
    return send_from_directory(DOSSIER_UPLOADS, nom)


# ====================== AUTHENTIFICATION AGENTS ======================
def login_requis(f):
    """Décorateur : redirige vers la page de connexion si l'agent n'est pas authentifié."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("agent_connecte"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper


PAGE_LOGIN = """
<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><title>Connexion agents</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body{font-family:system-ui,sans-serif;max-width:400px;margin:4rem auto;padding:0 1rem;color:#1a1a1a}
  .carte{background:#f0f4f0;border:1px solid #d0e0d0;border-radius:12px;padding:2rem}
  h1{font-size:1.2rem;color:#1a5c1a;text-align:center}
  input{width:100%;box-sizing:border-box;padding:.8rem;margin:.6rem 0;border:1px solid #ccc;border-radius:8px;font-size:1rem}
  button{width:100%;padding:.9rem;background:#1a5c1a;color:#fff;border:none;border-radius:8px;
    font-size:1rem;font-weight:600;cursor:pointer}
  .err{color:#c0392b;text-align:center;margin-top:.5rem}
  a{color:#1a5c1a}
</style></head>
<body>
  <div class="carte">
    <h1>🔒 Espace agents municipaux</h1>
    <form method="post">
      <input type="password" name="mot_de_passe" placeholder="Mot de passe" required autofocus>
      <button type="submit">Se connecter</button>
    </form>
    {% if erreur %}<div class="err">{{ erreur }}</div>{% endif %}
  </div>
  <p style="text-align:center;margin-top:1rem"><a href="{{ url_for('accueil') }}">← Retour</a></p>
</body></html>
"""


@app.route("/login", methods=["GET", "POST"])
def login():
    erreur = None
    if request.method == "POST":
        if request.form.get("mot_de_passe") == MOT_DE_PASSE_AGENTS:
            session["agent_connecte"] = True
            return redirect(url_for("dashboard"))
        erreur = "Mot de passe incorrect."
    return render_template_string(PAGE_LOGIN, erreur=erreur)


@app.route("/logout")
def logout():
    session.pop("agent_connecte", None)
    return redirect(url_for("accueil"))


# ====================== DASHBOARD AGENTS (Point 5) ======================
PAGE_DASHBOARD = """
<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><title>Dashboard agents — SmartWaste</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
  body{font-family:system-ui,sans-serif;max-width:1100px;margin:0 auto;padding:1rem;color:#1a1a1a}
  header{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem}
  h1{font-size:1.3rem;margin:.3rem 0}
  h2{font-size:1.05rem;margin:1.5rem 0 .6rem}
  a.logout{color:#c0392b;text-decoration:none;font-size:.9rem}
  .cartes{display:flex;gap:1rem;flex-wrap:wrap;margin:1rem 0}
  .stat{flex:1;min-width:130px;background:#f0f4f0;border:1px solid #d0e0d0;border-radius:12px;padding:1rem;text-align:center}
  .stat .n{font-size:1.8rem;font-weight:700;color:#1a5c1a}
  .stat .l{font-size:.85rem;color:#666}
  #map{height:380px;border-radius:12px;border:1px solid #ccc;margin-bottom:1rem}
  .grille{display:grid;grid-template-columns:1fr 1fr;gap:1.5rem}
  @media(max-width:700px){.grille{grid-template-columns:1fr}}
  table{width:100%;border-collapse:collapse}
  th,td{text-align:left;padding:.5rem;border-bottom:1px solid #eee;font-size:.9rem}
  .badge{display:inline-block;padding:.15rem .5rem;border-radius:6px;color:#fff;font-weight:700;font-size:.8rem}
  .b_vide{background:#2e8b57}.b_a_moitie{background:#e0a800}.b_pleine{background:#c0392b}.b_inconnu{background:#999}
  .alerte{background:#fdecea;border:1px solid #f5c6cb;border-radius:8px;padding:.5rem .8rem;margin:.3rem 0;color:#a3221a}
  .risque{background:#fff8e1;border:1px solid #ffe08a;border-radius:8px;padding:.5rem .8rem;margin:.3rem 0;color:#7a5b00}
  .vide-msg{color:#666;font-style:italic}
</style></head>
<body>
  <header>
    <h1>📊 Tableau de bord — services de collecte</h1>
    <a class="logout" href="{{ url_for('logout') }}">Déconnexion</a>
  </header>
  <p><a href="{{ url_for('admin_regles') }}" style="color:#1a5c1a;font-weight:600">⚙️ Configurer les règles de classification</a></p>

  <!-- Statistiques clés -->
  <div class="cartes">
    <div class="stat"><div class="n">{{ rep['pleine'] }}</div><div class="l">Pleines 🔴</div></div>
    <div class="stat"><div class="n">{{ rep['a_moitie'] }}</div><div class="l">À moitié 🟠</div></div>
    <div class="stat"><div class="n">{{ rep['vide'] }}</div><div class="l">Vides 🟢</div></div>
    <div class="stat"><div class="n">{{ stats['total'] }}</div><div class="l">Signalements</div></div>
    <div class="stat"><div class="n">{{ stats['taux_accord'] }}%</div><div class="l">Accord IA/citoyen</div></div>
  </div>

  <!-- Carte -->
  <h2>🗺️ Carte des poubelles</h2>
  <div id="map"></div>

  <div class="grille">
    <div>
      <!-- Alertes : poubelles pleines -->
      <h2>🚨 À collecter en priorité</h2>
      {% if pleines %}
        {% for p in pleines %}
          <div class="alerte"><b>{{ p['id'] }}</b> — {{ p['nom_lieu'] }}</div>
        {% endfor %}
      {% else %}
        <p class="vide-msg">Aucune poubelle pleine actuellement.</p>
      {% endif %}

      <!-- Zones à risque -->
      <h2>⚠️ Zones à risque de débordement</h2>
      {% if risques %}
        {% for r in risques %}
          <div class="risque"><b>{{ r['id'] }}</b> — {{ r['nom_lieu'] }}
            ({{ r['taux_pleine'] }}% de signalements "pleine")</div>
        {% endfor %}
      {% else %}
        <p class="vide-msg">Pas assez de données pour identifier des zones à risque.</p>
      {% endif %}
    </div>

    <div>
      <!-- Graphique signalements par jour -->
      <h2>📈 Signalements par jour</h2>
      <canvas id="chartJours" height="160"></canvas>

      <!-- Tableau récap -->
      <h2>📋 Toutes les poubelles</h2>
      <table>
        <tr><th>ID</th><th>Lieu</th><th>Statut</th></tr>
        {% for p in carte %}
        <tr>
          <td>{{ p['id'] }}</td>
          <td>{{ p['nom_lieu'] }}</td>
          <td>
            {% if p['statut'] %}<span class="badge b_{{ p['statut'] }}">{{ aff[p['statut']] }}</span>
            {% else %}<span class="badge b_inconnu">—</span>{% endif %}
          </td>
        </tr>
        {% endfor %}
      </table>
    </div>
  </div>

  <script>
    // ---- Carte Leaflet ----
    const poubelles = {{ carte_json|safe }};
    const couleurs = {vide:"#2e8b57", a_moitie:"#e0a800", pleine:"#c0392b", null:"#999"};
    const labels = {vide:"Vide", a_moitie:"À moitié", pleine:"Pleine", null:"Aucune donnée"};

    // Centre la carte sur la moyenne des poubelles (ou Paris par défaut)
    let lat = 48.86, lon = 2.35;
    if (poubelles.length) {
      lat = poubelles.reduce((s,p)=>s+p.latitude,0)/poubelles.length;
      lon = poubelles.reduce((s,p)=>s+p.longitude,0)/poubelles.length;
    }
    const map = L.map('map').setView([lat, lon], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap', maxZoom: 19
    }).addTo(map);

    poubelles.forEach(p => {
      const c = couleurs[p.statut] || couleurs[null];
      L.circleMarker([p.latitude, p.longitude], {
        radius: 10, fillColor: c, color: "#fff", weight: 2, fillOpacity: 0.9
      }).addTo(map).bindPopup(
        `<b>${p.id}</b><br>${p.nom_lieu}<br>Statut : ${labels[p.statut]||labels[null]}` +
        (p.derniere_maj ? `<br><small>Maj : ${p.derniere_maj}</small>` : "")
      );
    });

    // ---- Graphique signalements par jour ----
    new Chart(document.getElementById('chartJours'), {
      type: 'bar',
      data: {
        labels: {{ jours_dates|safe }},
        datasets: [{ label: 'Signalements', data: {{ jours_comptes|safe }},
                     backgroundColor: '#1a5c1a' }]
      },
      options: { plugins:{legend:{display:false}}, scales:{y:{beginAtZero:true,ticks:{precision:0}}} }
    });
  </script>
</body></html>
"""


@app.route("/dashboard")
@login_requis
def dashboard():
    import json as _json
    carte = donnees_carte(n=5)
    rep = repartition_statuts(n=5)
    stats = compter_signalements()
    pleines = poubelles_pleines(n=5)
    risques = zones_a_risque(seuil_taux=0.4, mini_signalements=3)
    jours_dates, jours_comptes = signalements_par_jour(14)

    return render_template_string(
        PAGE_DASHBOARD,
        carte=carte,
        carte_json=_json.dumps(carte),
        rep=rep,
        stats=stats,
        pleines=pleines,
        risques=risques,
        jours_dates=_json.dumps(jours_dates),
        jours_comptes=_json.dumps(jours_comptes),
        aff=LABEL_AFFICHAGE,
    )


# ====================== ADMIN : RÈGLES CONFIGURABLES (Point niveau 2-3) ======================
PAGE_ADMIN_REGLES = """
<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><title>Admin — Règles</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body{font-family:system-ui,sans-serif;max-width:900px;margin:0 auto;padding:1rem;color:#1a1a1a}
  header{display:flex;justify-content:space-between;align-items:center}
  h1{font-size:1.3rem}h2{font-size:1.05rem;margin-top:1.5rem}
  .bloc{background:#f0f4f0;border:1px solid #d0e0d0;border-radius:12px;padding:1.2rem;margin:1rem 0}
  label{display:block;font-size:.85rem;color:#555;margin-top:.5rem}
  input,select{padding:.5rem;border:1px solid #ccc;border-radius:6px;font-size:.95rem}
  .grille-seuils{display:grid;grid-template-columns:1fr 1fr;gap:.5rem 1rem}
  @media(max-width:600px){.grille-seuils{grid-template-columns:1fr}}
  button{padding:.6rem 1rem;border:none;border-radius:8px;font-weight:600;cursor:pointer;color:#fff}
  .vert{background:#1a5c1a}.gris{background:#888}.rouge{background:#c0392b}.orange{background:#e0a800}
  table{width:100%;border-collapse:collapse;margin-top:.5rem}
  th,td{text-align:left;padding:.4rem;border-bottom:1px solid #eee;font-size:.9rem}
  .msg{background:#e8f5e9;border:1px solid #a5d6a7;border-radius:8px;padding:.6rem;color:#1b5e20;margin:.5rem 0}
  .inactive{opacity:.45}
  a{color:#1a5c1a}
  .ligne-form{display:flex;gap:.5rem;flex-wrap:wrap;align-items:end}
</style></head>
<body>
  <header>
    <h1>⚙️ Configuration des règles de classification</h1>
    <a href="{{ url_for('dashboard') }}">← Dashboard</a>
  </header>
  {% if message %}<div class="msg">{{ message }}</div>{% endif %}

  <!-- SEUILS AJUSTABLES -->
  <div class="bloc">
    <h2>1. Seuils ajustables</h2>
    <p style="font-size:.85rem;color:#666">Ces seuils pilotent la classification par défaut et le contrôle de conformité.</p>
    <form method="post" action="{{ url_for('admin_seuils') }}">
      <div class="grille-seuils">
        {% for cle, val in seuils.items() %}
          <div><label>{{ cle }}</label>
            <input type="number" step="any" name="{{ cle }}" value="{{ val }}"></div>
        {% endfor %}
      </div>
      <div style="margin-top:1rem">
        <button class="vert" type="submit">💾 Enregistrer les seuils</button>
      </div>
    </form>
    <form method="post" action="{{ url_for('admin_seuils_reset') }}" style="margin-top:.5rem">
      <button class="gris" type="submit">↺ Réinitialiser par défaut</button>
    </form>
  </div>

  <!-- RÈGLES LIBRES -->
  <div class="bloc">
    <h2>2. Règles libres (prioritaires)</h2>
    <p style="font-size:.85rem;color:#666">
      Format : SI &lt;caractéristique&gt; &lt;opérateur&gt; &lt;valeur&gt; ALORS &lt;niveau&gt;.
      Évaluées par priorité croissante ; la première qui s'applique l'emporte (avant les seuils).
    </p>
    <form method="post" action="{{ url_for('admin_ajouter_regle') }}" class="ligne-form">
      <div><label>SI</label>
        <select name="caracteristique">
          {% for c in caracteristiques %}<option value="{{ c }}">{{ c }}</option>{% endfor %}
        </select></div>
      <div><label>opérateur</label>
        <select name="operateur">
          {% for o in operateurs %}<option value="{{ o }}">{{ o }}</option>{% endfor %}
        </select></div>
      <div><label>valeur</label><input type="number" step="any" name="valeur" required></div>
      <div><label>ALORS</label>
        <select name="label">
          <option value="vide">vide</option>
          <option value="a_moitie">a_moitie</option>
          <option value="pleine">pleine</option>
        </select></div>
      <div><label>priorité</label><input type="number" name="priorite" value="100" style="width:80px"></div>
      <div><button class="vert" type="submit">+ Ajouter</button></div>
    </form>

    <table>
      <tr><th>Prio</th><th>Règle</th><th>État</th><th>Actions</th></tr>
      {% for r in regles %}
      <tr class="{{ '' if r['active'] else 'inactive' }}">
        <td>{{ r['priorite'] }}</td>
        <td>SI <b>{{ r['caracteristique'] }}</b> {{ r['operateur'] }} {{ r['valeur'] }}
            ALORS <b>{{ r['label'] }}</b></td>
        <td>{{ 'active' if r['active'] else 'désactivée' }}</td>
        <td>
          <form method="post" action="{{ url_for('admin_basculer_regle', regle_id=r['id']) }}" style="display:inline">
            <button class="orange" type="submit">{{ 'Désactiver' if r['active'] else 'Activer' }}</button>
          </form>
          <form method="post" action="{{ url_for('admin_supprimer_regle', regle_id=r['id']) }}" style="display:inline">
            <button class="rouge" type="submit">Suppr</button>
          </form>
        </td>
      </tr>
      {% else %}
      <tr><td colspan="4" style="color:#888">Aucune règle libre. La classification utilise les seuils ci-dessus.</td></tr>
      {% endfor %}
    </table>
  </div>
</body></html>
"""


@app.route("/admin/regles")
@login_requis
def admin_regles():
    message = request.args.get("msg")
    return render_template_string(
        PAGE_ADMIN_REGLES,
        seuils=get_seuils(),
        regles=lister_regles(),
        caracteristiques=CARACTERISTIQUES_REGLES,
        operateurs=OPERATEURS_REGLES,
        message=message,
    )


@app.route("/admin/seuils", methods=["POST"])
@login_requis
def admin_seuils():
    nouveaux = {}
    for cle in get_seuils().keys():
        val = request.form.get(cle)
        if val is not None and val != "":
            try:
                nouveaux[cle] = float(val)
            except ValueError:
                pass
    maj_seuils(nouveaux)
    return redirect(url_for("admin_regles", msg="Seuils mis à jour."))


@app.route("/admin/seuils/reset", methods=["POST"])
@login_requis
def admin_seuils_reset():
    reinitialiser_seuils()
    return redirect(url_for("admin_regles", msg="Seuils réinitialisés aux valeurs par défaut."))


@app.route("/admin/regles/ajouter", methods=["POST"])
@login_requis
def admin_ajouter_regle():
    carac = request.form.get("caracteristique")
    op = request.form.get("operateur")
    label = request.form.get("label")
    try:
        valeur = float(request.form.get("valeur"))
        priorite = int(request.form.get("priorite", 100))
    except (ValueError, TypeError):
        return redirect(url_for("admin_regles", msg="Valeur ou priorité invalide."))
    if carac in CARACTERISTIQUES_REGLES and op in OPERATEURS_REGLES and label in LABELS_VALIDES:
        ajouter_regle(carac, op, valeur, label, priorite)
        return redirect(url_for("admin_regles", msg="Règle ajoutée."))
    return redirect(url_for("admin_regles", msg="Règle invalide."))


@app.route("/admin/regles/<int:regle_id>/basculer", methods=["POST"])
@login_requis
def admin_basculer_regle(regle_id):
    basculer_regle(regle_id)
    return redirect(url_for("admin_regles"))


@app.route("/admin/regles/<int:regle_id>/supprimer", methods=["POST"])
@login_requis
def admin_supprimer_regle(regle_id):
    supprimer_regle(regle_id)
    return redirect(url_for("admin_regles", msg="Règle supprimée."))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)

